<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Dashboard</div>
                    <div class="card-body">
					<?php if(session()->has('message')): ?>
						<div class="alert alert-success">
							<?php echo e(session()->get('message')); ?>

						</div>
					<?php endif; ?>
					<div class="table-responsive">
						<table class="table">
							<thead>
								<tr>
									<th>Name</th>
									<th>Description</th>
									<th>Amount</th>
									<th>Status</th>
									<th>Delete</th>
									<th class="text-center" style="width: 10%;"><i class="
										icon-circle-down2"></i></th>
								</tr>
							</thead>
							<tbody>
							  <?php if(!empty($claims) && $claims->count()): ?>
								<?php $__currentLoopData = $claims; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $claim): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
									
									<td><?php echo e($claim->name); ?></td>
									<td>
										<span class="badge badge-flat border-grey-800 text-default text-capitalize">
										<?php echo e($claim->description); ?>

										</span>
									</td>
									<td>
										<?php echo e($claim->description); ?>amount
									</td>
									<td><?php if($claim->status ==0): ?>
										<a class="btn btn-success text-white" href="<?php echo e(URL::route('admin.statusUpdate', $claim->id )); ?>" id="appr">
										Approve
										<i class="icon-trash ml-1"></i>
										</a>
										<?php elseif($claim->status ==1): ?>

										<a class="btn btn-danger text-white" href="<?php echo e(URL::route('admin.statusUpdate', $claim->id)); ?>" id="rej">
										Reject
										<i class="icon-trash ml-1"></i>
										</a>
										<?php else: ?>
										
										<span class="badge badge-flat text-default text-capitalize">
										<span class="btn-danger"></span>
										<?php endif; ?>
										</span>
									</td>
									<td class="text-center">
										<a class="btn btn-danger text-white" href="<?php echo e(URL::route('admin.deleteClaims', $claim->id)); ?>" id="deleteClaimsButton">
										DELETE
										<i class="icon-trash ml-1"></i>
										</a>
									</td>
								</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<?php else: ?>
								<tr>
									<td colspan="10">There are no Records.</td>
								</tr>
								<?php endif; ?>
							</tbody>
						</table>
						<?php echo $claims->links(); ?>

					</div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/ppandi/demo/guestbook_master/resources/views/viewClaims.blade.php ENDPATH**/ ?>